class MSConfig {
  static const String msIpHttp = '192.168.100.1';
  static const String mioPc = 'localhost';
}
class ApiConfig {
  static const String baseUrl = 'https://freetimeai.freeddns.org';
}

class freeTimeAi{


}